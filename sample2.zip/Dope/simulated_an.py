import numpy as np
import matplotlib.pyplot as plt

# Function
def f(x):
    return x**3 - 2*x**2 - 10*x + 10

# Parameters
T = 100
T_min = 1e-3
alpha = 0.9

# Initial solution
x = np.random.uniform(-3, 3)
best_x = x
best_f = f(x)

# Store points for plotting
x_vals = []
y_vals = []

while T > T_min:
    for _ in range(100):
        x_new = x + np.random.uniform(-0.5, 0.5)
        x_new = np.clip(x_new, -3, 3)

        delta = f(x_new) - f(x)

        if delta < 0 or np.random.rand() < np.exp(-delta / T):
            x = x_new

        if f(x) < best_f:
            best_x = x
            best_f = f(x)

        x_vals.append(x)
        y_vals.append(f(x))

    T *= alpha

print("Optimal x:", best_x)
print("Optimal value:", best_f)

# Plot
x_plot = np.linspace(-3, 3, 200)
y_plot = f(x_plot)

plt.plot(x_plot, y_plot, label="Function")
plt.scatter(best_x, best_f, color='red', label="Optimal Point")
plt.title("Simulated Annealing Optimization")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.legend()
plt.grid()
plt.show()