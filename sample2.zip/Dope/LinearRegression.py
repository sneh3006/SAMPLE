import numpy as np
import matplotlib.pyplot as plt

# Generate data
np.random.seed(0)
x = np.linspace(0, 10, 40)
noise = np.random.randn(40) * 2
y = 2.5*x + 5 + noise

# Design matrix
X = np.vstack([np.ones(len(x)), x]).T

# Least squares solution
theta = np.linalg.inv(X.T @ X) @ X.T @ y

intercept = theta[0]
slope = theta[1]

# Predictions
y_pred = intercept + slope * x

# Plot
plt.scatter(x, y, label="Data Points (Noisy)")
plt.plot(x, y_pred, color='red',
         label=f"Fitted Line: y={slope:.2f}x+{intercept:.2f}")

plt.xlabel("Independent Variable (x)")
plt.ylabel("Dependent Variable (y)")
plt.title("Linear Regression: Least Squares Method")
plt.legend()
plt.grid()
plt.show()