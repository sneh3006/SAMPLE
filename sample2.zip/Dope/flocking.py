import numpy as np
import matplotlib.pyplot as plt

# Parameters
N = 40
width, height = 30, 30
max_speed = 0.5
radius = 3.0

# Weights
w_sep, w_align, w_coh = 1.2, 1.0, 1.5

# Initialization
pos = np.random.rand(N,2) * [width, height]
vel = (np.random.rand(N,2) - 0.5)

def limit(v):
    s = np.linalg.norm(v)
    if s > max_speed:
        return v/s * max_speed
    return v

def update():
    global pos, vel
    new_vel = vel.copy()

    for i in range(N):
        neighbors = []
        for j in range(N):
            if i != j:
                if np.linalg.norm(pos[i]-pos[j]) < radius:
                    neighbors.append(j)

        if neighbors:
            # Separation
            sep = np.zeros(2)
            for j in neighbors:
                diff = pos[i] - pos[j]
                d = np.linalg.norm(diff)
                if d > 0:
                    sep += diff/d

            # Alignment
            align = np.mean(vel[neighbors], axis=0) - vel[i]

            # Cohesion
            center = np.mean(pos[neighbors], axis=0)
            coh = center - pos[i]

            new_vel[i] += w_sep*sep + w_align*align + w_coh*coh

        new_vel[i] = limit(new_vel[i])

    vel[:] = new_vel
    pos[:] += vel
    pos[:] = pos % [width, height]

# Visualization
plt.figure(figsize=(6,6))
plt.ion()

for _ in range(200):
    update()
    plt.clf()
    plt.quiver(pos[:,0], pos[:,1], vel[:,0], vel[:,1])
    plt.xlim(0, width)
    plt.ylim(0, height)
    plt.title("Boids Flocking Simulation")
    plt.pause(0.05)

plt.ioff()
plt.show()