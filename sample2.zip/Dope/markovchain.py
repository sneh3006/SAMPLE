import numpy as np

P = np.array([
    [0.2, 0.6, 0.2],
    [0.3, 0.0, 0.7],
    [0.5, 0.3, 0.2]
])

# Power Iteration Method
pi = np.array([1.0, 0.0, 0.0])

tolerance = 1e-6
max_iter = 100

for i in range(max_iter):
    pi_next = pi @ P
    if np.linalg.norm(pi_next - pi) < tolerance:
        break
    pi = pi_next

print("Power Method Result:", pi)

#Eigenvector Method

eigvals, eigvecs = np.linalg.eig(P.T)
index = np.argmin(np.abs(eigvals - 1))
pi = np.real(eigvecs[:, index])
pi = pi / np.sum(pi)

print("Eigenvalue Method Result:", pi)


A = P.T - np.eye(3)
A = np.vstack([A, np.ones(3)])
b = np.array([0, 0, 0, 1])

pi = np.linalg.lstsq(A, b, rcond=None)[0]

print("Algebraic Method Result:", pi)